import getpass
import os

os.system("title Prime Script: read.prime")
errors = ""
script = []
floc = 0
while not ".prime" in os.listdir(f"C:/Users/{getpass.getuser()}/Desktop/PRIME/")[floc]:
    floc +=1
file = os.listdir(f"C:/Users/{getpass.getuser()}/Desktop/PRIME/")[floc]
os.system(f"title Prime Script: {file}")
sysinput = ""
f = open(f"C:/Users/{getpass.getuser()}/Desktop/PRIME/{file}", "r")
for line in f:
    script.append(line)
n = 0
i = script[n]
itm = ""
loc = 0
while not n == len(script):
    n += 1
    i = script[n-1]
    itm = ""
    loc = 0
    if "system.display(" in i:
        loc = 0
        loc = 15
        itm = ""
        while not i[loc+1] == "\"":
            loc += 1
            itm = itm + i[loc]
        if itm == "":
            errors = errors + f"\nERR [Ln {n-1}]: Nothing to Print."
        else:
            if "import system\n" in script:
                print(itm)
            else:
                errors = errors + f"\nERR [Ln {n-1}]: Define \"system\""
    if "system.input(" in i:
        loc = 0
        loc = 14
        itm = ""
        while not i[loc+1] == "\"":
            loc += 1
            itm + itm + i[loc]
        if "import system\n" in script:
            sysinput = input(itm)
        else:
            errors = errors + f"\nERR [Ln {n-1}]: Define \"system\""
    if "system.clear(" in i:
        if not "()" in i:
            errors = f"\nERR [Ln {n-1}]: Function built for no args"
        else:
            if "import system\n" in script:
                os.system("cls")
            else:
                errors = errors + f"\nERR [Ln {n-1}]: Define \"system\""
    if "system.file.direct(" in i:
        loc = 0
        loc = 19
        itm = ""
        while not i[loc+1] == "\"":
            loc += 1
            itm = itm + i[loc]
        if itm == "":
            errors = errors + f"\nERR [Ln {n-1}]: Path empty"
        else:
            if "import system\n" in script:
                f = open(itm, "r")
                script = []
                n = 0
                os.system("cls")
                os.system(f"title {itm}")
                for line in f:
                    script.append(line)
            else:
                errors = errors + f"\nERR [Ln {n-1}]: Define \"system\""
    if "system.color(" in i:
        loc = 0
        loc = 13
        itm = ""
        while not i[loc+1] == "\"":
            loc += 1
            itm = itm + i[loc]
        if "import system\n" in script:
            os.system(f"color {itm}")
        else:
            errors = errors + f"\nERR [Ln {n-1}]: Define \"system\""
if not errors == "":
    os.system("cls")
    os.system("color 4")
print(errors)
os.system("pause")
