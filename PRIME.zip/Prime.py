import getpass
import os

os.system("title Prime Script: read.prime")
errors = ""
script = []
floc = 0
cloc = 0
while not ".prime" in os.listdir(f"C:/Users/{getpass.getuser()}/Desktop/PRIME/")[floc]:
    floc += 1
file = os.listdir(f"C:/Users/{getpass.getuser()}/Desktop/PRIME/")[floc]
os.system(f"title Prime Script: {file}")
f = open(f"C:/Users/{getpass.getuser()}/Desktop/PRIME/{file}", "r")
for line in f:
    script.append(line)

vlist = []
n = 0
i = script[n]
itm = ""
loc = 0
ref = 0
dou = []
douv = 0
while not n == len(script):
    n += 1
    i = script[n-1]
    itm = ""
    loc = 0
    if "system.display(" in i:
        loc = 0
        loc = 15
        itm = ""
        if not i[15] == ">":
            while not i[loc+1] == "\"":
                loc += 1
                itm = itm + i[loc]
            if itm == "":
                errors = errors + f"\nERR [Ln {n-1}]: Nothing to Print."
            else:
                if "import system\n" in script:
                    print(itm)
                else:
                    errors = errors + f"\nERR [Ln {n-1}]: Define \"system\""
        else:
            while not i[loc+1] == ")":
                loc += 1
                itm = itm + i[loc]
            if itm in vlist:
                print(vlist[vlist.index(itm)+1])
            else:
                errors = errors + f"\nERR [Ln {n-1}]: Variable \"{itm}\" does Not Exist."
            if "+" in itm or "-" in itm or "*" in itm or "/" in itm:
                loc = 15
                itm = ""
                while i[loc+1] in "1234567890":
                    loc += 1
                    itm = itm + i[loc]
                dou.append(itm)
                loc += 1
                itm = ""
                while i[loc+1] in "1234567890":
                    loc += 1
                    itm = itm + i[loc]
                dou.append(itm)
                if "+" in i:
                    print(int(dou[0]) + int(dou[1]))
                if "-" in i:
                    print(int(dou[0]) - int(dou[1]))
                if "*" in i:
                    print(int(dou[0]) * int(dou[1]))
                if "/" in i:
                    print(int(dou[0]) / int(dou[1]))
                
    if "system.input(" in i:
        loc = 0
        loc = 13
        itm = ""
        while not i[loc+1] == "\"":
            loc += 1
            itm + itm + i[loc]
        if "import system\n" in script:
            if not "system.input" in vlist:
                vlist.append("system.input")
                vlist.append("")
            vlist[vlist.index("system.input")+1] = input(itm)
        else:
            errors = errors + f"\nERR [Ln {n-1}]: Define \"system\""
    if "system.clear(" in i:
        if not "()" in i:
            errors = f"\nERR [Ln {n-1}]: Function built for no args"
        else:
            if "import system\n" in script:
                os.system("cls")
            else:
                errors = errors + f"\nERR [Ln {n-1}]: Define \"system\""
    if "system.file.direct(" in i:
        loc = 0
        loc = 19
        itm = ""
        if not ">" in i:
            while not i[loc+1] == "\"":
                loc += 1
                itm = itm + i[loc]
            if itm == "":
                errors = errors + f"\nERR [Ln {n-1}]: Path empty"
            else:
                if "import system\n" in script:
                    f = open(itm, "r")
                    script = []
                    n = 0
                    os.system("cls")
                    os.system(f"title {itm}")
                    for line in f:
                        script.append(line)
                else:
                    errors = errors + f"\nERR [Ln {n-1}]: Define \"system\""
        else:
            print("Func WIP")
            #while not i[loc+1] == ")":
                #loc += 1
                #itm = itm + i[loc]
            #if not itm == "":
                #dou = [vlist[vlist.index(itm)+1], ""]
                #if "import system\n" in script:
                    #f = open(dou[0], "r")
                    #n = 0
                    #os.system("cls")
                    #os.system(f"title {dou[0]}")
                    #for line in f:
                        #script.append(line)
                #else:
                    #errors = errors + f"\nERR [Ln {n-1}]: Define \"system\"" 
            #else: 
                #errors = errors + f"\nERR [Ln {n-1}]: Path empty"

    if "system.color(" in i:
        loc = 0
        loc = 13
        itm = ""
        while not i[loc+1] == "\"":
            loc += 1
            itm = itm + i[loc]
        if "import system\n" in script:
            os.system(f"color {itm}")
        else:
            errors = errors + f"\nERR [Ln {n-1}]: Define \"system\""

    if i == "/*":
        while not script[n-1] == "*/":
            n += 1

    if "var " in i:
        loc = 3
        itm = ""
        while not i[loc+1] == " ":
            loc += 1
            itm = itm + i[loc]
        if not itm in vlist:
            vlist.append(itm)
            vlist.append("")
        dou = [itm]
        if "\"" in i:
            loc = i.index("\"")
            itm = ""
            while not i[loc+1] == "\"":
                loc += 1
                itm = itm + i[loc]
            vlist[vlist.index(dou[0])+1] = itm
        else:
            loc = i.index(">")
            itm = ""
            while not i[loc+1] == ")":
                loc += 1
                itm = itm + i[loc]
            if itm in vlist:
                vlist[vlist.index(dou[0])+1] = vlist[vlist.index(itm)+1]
            else:
                errors = errors + f"\nERR [Ln {n-1}]: Variable \"{itm}\" does Not Exist."
                
    if "arr " in i:
        loc = 3
        itm = ""
        while not i[loc+1] == " ":
            loc += 1
            itm = itm + i[loc]
        if not itm in vlist:
            vlist.append(itm)
            vlist.append("")
        dou = [itm]
        while not "};" in script[n]:
            if not "};" in script[n]:
                if not ">" in script[n]:
                    vlist[vlist.index(dou[0])+1] = vlist[vlist.index(dou[0])+1] + script[n]
                else:
                    itm = ""
                    loc = 1
                    while not script[n][loc] == "\n":
                        loc += 1
                        itm = itm + script[n][loc-1]
                    vlist[vlist.index(dou[0])+1] = vlist[vlist.index(dou[0])+1] + "\"" + vlist[vlist.index(itm)+1] + "\"\n"
            n += 1

    if "import system" in i:
        vlist.append("system.username")
        vlist.append(getpass.getuser())

    if "importfrmdir " in i:
        loc = 12
        itm = ""
        while not loc == len(i)-1:
            loc += 1
            if i[loc] != "\n":
                itm = itm + i[loc]
        f = open(itm, "r")
        for line in f:
            script.append(line)
    
if not errors == "":
    os.system("cls")
    os.system("color 4")
print(errors)
os.system("pause")
