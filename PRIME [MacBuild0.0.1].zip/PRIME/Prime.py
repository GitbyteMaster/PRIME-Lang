import os
import getpass

filen = 0
maindir = os.listdir(f"/Users/{getpass.getuser()}/Desktop/PRIME")
file = ""
while not ".prime" in maindir[filen]:
    filen += 1
    file = f"/Users/{getpass.getuser()}/Desktop/PRIME/{maindir[filen]}"
n = 0
script = []
for line in file:
    script.append(line)
l = ""
loc = 0
itm = ""
while not n == len(script)-1:
    n += 1
    l = script[n-1]
    if "system.display(" in l:
        loc = l.index("(")+1
        itm = ""
        if "import system" in script:
            if "\"" in l:
                while l[loc+1]!= "\"":
                    loc += 1
                    itm = itm + l[loc]
                print(itm)
